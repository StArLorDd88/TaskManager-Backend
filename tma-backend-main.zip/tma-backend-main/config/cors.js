export const whiteListCors = [
    "http://localhost:3000",
    "http://localhost:3001",
    "http://192.168.29.155:3000",
    "http://192.168.29.100:3000",
]