import express from "express";
import http from "http";
import cors from "cors";
import cookieParser from "cookie-parser";
import bodyParser from "body-parser";
import morgan from "morgan";
import helmet from "helmet";
import xss from "xss-clean";
import compression from "compression";
import router from "./api-gateway/router.js";
import { whiteListCors } from "./config/cors.js";


const app = express();

// Middleware setup
app.use(cors({origin: whiteListCors, credentials: true,}));
app.use(morgan("dev"));
app.use(express.json({ limit: "5mb" }));
app.use(express.urlencoded({ extended: true, limit: "5mb" }));
app.use(helmet());
app.use(xss());
app.use(compression());
app.use(express.static("public"));
app.use(cookieParser());
app.use(bodyParser.json());

// Routes declaration
app.use("/test", (req, res) => {
  res.send("testing");
});

app.use("/api/v1", router);

const httpServer = http.createServer(app);

export default httpServer;
