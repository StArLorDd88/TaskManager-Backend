import { Router } from "express";
import { verifyJWT } from "../../middlewares/auth.middleware.js";
import projectController from './project.controller.js';

const router = Router();

router.route("/create-project").post(verifyJWT, projectController.createProject)


export default router;