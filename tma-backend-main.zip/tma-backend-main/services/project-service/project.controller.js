import { asyncHandler } from "../../utils/asyncHandler.js";
import { ApiError } from "../../utils/ApiError.js";
import { ApiResponse } from "../../utils/ApiResponse.js";
import { Project } from "../../models/project.model.js";

const pc = {}

pc.createProject = asyncHandler(async (req, res) => {
  console.log("req.body", req.body);
  
  try {
    const { name, access, key, description, startDate, endDate, priority, clientName, budget, projectManager, 
    teamMembers, rolesAndResponsibilities, milestones 
    } = req.body;
    
    const requiredFields = { name, access, key, startDate, endDate, priority, projectManager, rolesAndResponsibilities };
    
    const missingFields = Object.keys(requiredFields).filter(field => !requiredFields[field] || requiredFields[field] === 'undefined');
    
    if (missingFields.length > 0) {
    return res.status(400).json(new ApiError(400, `Missing required field: ${missingFields.join(', ')}`));
    }
    
    const createdProject = await Project.create({
      name, 
      access,
      key, 
      description, 
      startDate, 
      endDate, 
      priority, 
      clientName, 
      budget, 
      projectManager, 
      teamMembers, 
      rolesAndResponsibilities, 
      milestones,
      createdBy : req.user?._id
    });
    
    return res.status(201).json(new ApiResponse(201, createdProject, "Project created successfully"));
  } catch (error) {
    console.log("Error------",error)
    return res.status(400).json(new ApiError(404, error, "Error"));
  }   
  
});







export default pc