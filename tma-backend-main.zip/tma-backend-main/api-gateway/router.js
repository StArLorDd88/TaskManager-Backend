import { Router } from "express";
import userRouter from "../services/user-service/user.router.js";
import roleRouter from "../services/role-service/role.router.js";
import projectRouter from "../services/project-service/project.router.js";

const router = Router();

router.use("/user", userRouter);
router.use("/role", roleRouter);
router.use("/project", projectRouter);

export default router;
