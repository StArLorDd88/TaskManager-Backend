import "dotenv/config";
import httpServer from "./app.js";
import connectDB from "./config/db.config.js";

const port = process.env.PORT || 5001;

connectDB()
  .then(() => {
    httpServer.listen(port, () => {
      console.log(`⚙️ Server is running at http://localhost:${port}`);
    });
  })
  .catch((err) => {
    console.error("MongoDB connection failed!!!", err);
  });
